#find number is odd/even
'''num=int(input("Please enter the number"))

#> /< />= /<= / ! /logic 
if num%2==0 :
    print("Number is even")
else :
    print("Number is Odd")

'''
basicSal=int(input("please enter the basic salary"))

if basicSal > 5000:
    if basicSal <=10000:
        hra= basicSal * 0.10
        print("Hra is : " , hra)
    else :
        if basicSal >10001:
            if basicSal <=15000:
                hra= basicSal * 0.15
                print("Hra is : " , hra)
            else :
                print("Your salary is not below 15000")
        else :
             print("Your salary is not Greater Then 10000")
else :
    print("Your salary is not Greater Then 5000")










                
        
