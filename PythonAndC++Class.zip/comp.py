#COMPARE Two List Not use in Python 3 use only 2.0
#Remove Duplicate item

x=[2,2,3,4,5,5,6,7,8]

newList=[] #empty List

for i in x:
    #print(i)
    if i not in newList: 
        newList.append(i)  #2  

print(newList)        
