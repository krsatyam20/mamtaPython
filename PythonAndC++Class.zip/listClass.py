#Create empty list and Adding Elements to the list

#Declaring Empty list
x=[]

#Single element Append
'''x.append(12)

x.append(13)

x.append(14) '''

#Number of element Will be enter 
n=int(input("Enter the number of element in the list"))
#using Loop we will insert 5 element in list

for i in range(0,n):
    x.append(int(input("Please enter the item")))
    


#print all Item
print(x)

for i in x:
    print(i)

list1=[2,3,4,5]
#Remove Item from the list
list1.remove(2) 


print("After removing")
    
for l in list1:
    print(l)
    



    
