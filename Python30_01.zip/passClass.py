#pass: Keyword used for execute nothing


for i in range(1,10):
    if i==4:
        pass
        print("Here is pass block")
    print(i)


#Dictionary : store data with user define index key

#index key: name:mamta  here name is key and mamta is value

student={"name":"Mamta","Add":"Patna"}

print(student)

print(student['name'])

# create empty dictionary

cdit={}

cdit['name']="mamta"

print(cdit)

#using Dict function

cdit=dict({'name':"mamta",2:"JAiswal"})

print(cdit)

#Delete Element

#del cdit[2]

print(cdit.pop(2))

cdit=dict({'name':"mamta",2:"JAiswal"})

for s in cdit:
    print(cdit[s])

#print items of the dictionary

for s in cdit.items():
    print(s)












    




















    
