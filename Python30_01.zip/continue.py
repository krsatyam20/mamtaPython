n=1

while n<10:
    n=n+1
    
    if n==4:
        continue
    print(n)

