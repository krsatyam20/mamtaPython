#break:Reserved key word which is used for terminate loop in b/w
'''
n=1

while n<10:
    print(n)
    if n==4:
        break
    n=n+1

#2nd Example
list=[1,4,3,4]

for i in list:

        if i==4:
            break
        print(i)



n=int(input("plz enter any number for print table"))
while 1:
    i=1
    while i<=10:
        print(n,"*",i,"=",n*i)
        i=i+1
    ext=int(input("Do you want to continue printing table.. if u want to exit then press 0"))
    if ext==0:
        break
    n=int(input("plz enter any number for print table"))
        

'''

















